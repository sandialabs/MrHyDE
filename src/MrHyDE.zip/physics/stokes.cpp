/***********************************************************************
 MrHyDE - a framework for solving Multi-resolution Hybridized
 Differential Equations and enabling beyond forward simulation for 
 large-scale multiphysics and multiscale systems.
 
 Questions? Contact Tim Wildey (tmwilde@sandia.gov) 
************************************************************************/

#include "stokes.hpp"

using namespace MrHyDE;

// ========================================================================================
/* Constructor to set up the problem */
// ========================================================================================

template<class EvalT>
stokes<EvalT>::stokes(Teuchos::ParameterList & settings, const int & dimension_)
  : PhysicsBase<EvalT>(settings, dimension_)
{
  
  label = "stokes";
  int spaceDim = dimension_;
  
  myvars.push_back("ux");
  myvars.push_back("pr");
  if (spaceDim > 1) {
    myvars.push_back("uy");
  }
  if (spaceDim > 2) {
    myvars.push_back("uz");
  }
  
  mybasistypes.push_back("HGRAD");
  mybasistypes.push_back("HGRAD");
  if (spaceDim > 1) {
    mybasistypes.push_back("HGRAD");
  }
  if (spaceDim > 2) {
    mybasistypes.push_back("HGRAD");
  }
  
  
  useLSIC = settings.get<bool>("useLSIC",false);
  usePSPG = settings.get<bool>("usePSPG",false);
  
}

// ========================================================================================
// ========================================================================================

template<class EvalT>
void stokes<EvalT>::defineFunctions(Teuchos::ParameterList & fs,
                             Teuchos::RCP<FunctionManager<EvalT> > & functionManager_) {
  
  functionManager = functionManager_;
  
  functionManager->addFunction("source ux",fs.get<string>("source ux","0.0"),"ip");
  functionManager->addFunction("source pr",fs.get<string>("source pr","0.0"),"ip");
  functionManager->addFunction("source uy",fs.get<string>("source uy","0.0"),"ip");
  functionManager->addFunction("source uz",fs.get<string>("source uz","0.0"),"ip");
  functionManager->addFunction("viscosity",fs.get<string>("viscosity","1.0"),"ip");
  
}

// ========================================================================================
// ========================================================================================

template<class EvalT>
void stokes<EvalT>::volumeResidual() {
  
  int spaceDim = wkset->dimension;
  Vista<EvalT> visc, source_ux, source_pr, source_uy, source_uz;
  
  {
    Teuchos::TimeMonitor funceval(*volumeResidualFunc);
    source_ux = functionManager->evaluate("source ux","ip");
    source_pr = functionManager->evaluate("source pr","ip");
    if (spaceDim > 1) {
      source_uy = functionManager->evaluate("source uy","ip");
    }
    if (spaceDim > 2) {
      source_uz = functionManager->evaluate("source uz","ip");
    }
    visc = functionManager->evaluate("viscosity","ip");
  }
  
  Teuchos::TimeMonitor resideval(*volumeResidualFill);
  auto wts = wkset->wts;
  auto res = wkset->res;
  
  /////////////////////////////
  // ux equation
  /////////////////////////////
  
  if (spaceDim == 1) {
    auto dux_dx = wkset->getSolutionField("grad(ux)[x]");
    auto Pr = wkset->getSolutionField("pr");
    {
      int ux_basis = wkset->usebasis[ux_num];
      auto basis = wkset->basis[ux_basis];
      auto basis_grad = wkset->basis_grad[ux_basis];
      auto off = subview(wkset->offsets,ux_num,ALL());
      parallel_for("Stokes ux volume resid",
                   RangePolicy<AssemblyExec>(0,wkset->numElem),
                   MRHYDE_LAMBDA (const int elem ) {
        for (size_type pt=0; pt<basis.extent(2); pt++ ) {
          EvalT Fx = visc(elem,pt)*dux_dx(elem,pt) - Pr(elem,pt);
          Fx *= wts(elem,pt);
          EvalT g = -source_ux(elem,pt)*wts(elem,pt);
          for (size_type dof=0; dof<basis.extent(1); dof++ ) {
            res(elem,off(dof)) += Fx*basis_grad(elem,dof,pt,0) + g*basis(elem,dof,pt,0);
          }
        }
      });
    }
    
    {
      int pr_basis = wkset->usebasis[pr_num];
      auto basis = wkset->basis[pr_basis];
      auto basis_grad = wkset->basis_grad[pr_basis];
      auto off = subview(wkset->offsets,pr_num,ALL());
      
      parallel_for("Stokes pr volume resid",
                   RangePolicy<AssemblyExec>(0,wkset->numElem),
                   MRHYDE_LAMBDA (const int elem ) {
        for( size_type pt=0; pt<basis.extent(2); pt++ ) {
          EvalT divu = dux_dx(elem,pt);
          divu *= wts(elem,pt);
          for( size_type dof=0; dof<basis.extent(1); dof++ ) {
            res(elem,off(dof)) += divu*basis(elem,dof,pt,0);
          }
        }
      });

      if (usePSPG) {
        
        auto h = wkset->getElementSize();
        auto dpr_dx = wkset->getSolutionField("grad(pr)[x]");
        
        parallel_for("Stokes pr volume resid",
                     RangePolicy<AssemblyExec>(0,wkset->numElem),
                     MRHYDE_LAMBDA (const int elem ) {
          ScalarT alpha = 1.0;
          for (size_type pt=0; pt<basis.extent(2); pt++ ) {
            EvalT tau = alpha*h(elem)*h(elem)/(2.*visc(elem,pt));
            EvalT stabres = dpr_dx(elem,pt) + source_ux(elem,pt);
            EvalT Sx = tau*stabres*wts(elem,pt);
            for( size_type dof=0; dof<basis.extent(1); dof++ ) {
              res(elem,off(dof)) += Sx*basis_grad(elem,dof,pt,0);
            }
          }
        });
      }

      if (useLSIC) {
        
        auto h = wkset->getElementSize();
        auto dux_dx = wkset->getSolutionField("grad(ux)[x]");
        
        parallel_for("Stokes pr volume resid",
                     RangePolicy<AssemblyExec>(0,wkset->numElem),
                     MRHYDE_LAMBDA (const int elem ) {
          ScalarT alpha = 1.0;
          for (size_type pt=0; pt<basis.extent(2); pt++ ) {
            EvalT tau = alpha*h(elem)*h(elem)/(2.*visc(elem,pt));
            EvalT stabres = dux_dx(elem,pt);
            EvalT S = tau*stabres*wts(elem,pt);
            for( size_type dof=0; dof<basis.extent(1); dof++ ) {
              res(elem,off(dof)) += S*basis_grad(elem,dof,pt,0);
            }
          }
        });
      }
    }
  }
  
  if (spaceDim == 2) {
    auto dux_dx = wkset->getSolutionField("grad(ux)[x]");
    auto dux_dy = wkset->getSolutionField("grad(ux)[y]");
    auto duy_dx = wkset->getSolutionField("grad(uy)[x]");
    auto duy_dy = wkset->getSolutionField("grad(uy)[y]");
    auto Pr = wkset->getSolutionField("pr");
    {
      int ux_basis = wkset->usebasis[ux_num];
      auto basis = wkset->basis[ux_basis];
      auto basis_grad = wkset->basis_grad[ux_basis];
      auto off = Kokkos::subview(wkset->offsets,ux_num,Kokkos::ALL());
      parallel_for("Stokes ux volume resid",
                   RangePolicy<AssemblyExec>(0,wkset->numElem),
                   MRHYDE_LAMBDA (const int elem ) {
        for (size_type pt=0; pt<basis.extent(2); pt++ ) {
          EvalT Fx = visc(elem,pt)*dux_dx(elem,pt) - Pr(elem,pt);
          Fx *= wts(elem,pt);
          EvalT Fy = visc(elem,pt)*dux_dy(elem,pt);
          Fy *= wts(elem,pt);
          EvalT g = -source_ux(elem,pt)*wts(elem,pt);
          for (size_type dof=0; dof<basis.extent(1); dof++ ) {
            res(elem,off(dof)) += Fx*basis_grad(elem,dof,pt,0) + Fy*basis_grad(elem,dof,pt,1) + g*basis(elem,dof,pt,0);
          }
        }
      });
    }
    
    {
      int uy_basis = wkset->usebasis[uy_num];
      auto basis = wkset->basis[uy_basis];
      auto basis_grad = wkset->basis_grad[uy_basis];
      auto off = subview(wkset->offsets,uy_num,ALL());
      parallel_for("Stokes uy volume resid",
                   RangePolicy<AssemblyExec>(0,wkset->numElem),
                   MRHYDE_LAMBDA (const int elem ) {
        for( size_type pt=0; pt<basis.extent(2); pt++ ) {
          EvalT Fx = visc(elem,pt)*duy_dx(elem,pt);
          Fx *= wts(elem,pt);
          EvalT Fy = visc(elem,pt)*duy_dy(elem,pt) - Pr(elem,pt);
          Fy *= wts(elem,pt);
          EvalT g = -source_uy(elem,pt)*wts(elem,pt);
          for (size_type dof=0; dof<basis.extent(1); dof++ ) {
            res(elem,off(dof)) += Fx*basis_grad(elem,dof,pt,0) + Fy*basis_grad(elem,dof,pt,1) + g*basis(elem,dof,pt,0);
          }
        }
      });
    }
    
    {
      int pr_basis = wkset->usebasis[pr_num];
      auto basis = wkset->basis[pr_basis];
      auto basis_grad = wkset->basis_grad[pr_basis];
      auto off = Kokkos::subview(wkset->offsets,pr_num,Kokkos::ALL());
      
      parallel_for("Stokes pr volume resid",
                   RangePolicy<AssemblyExec>(0,wkset->numElem),
                   MRHYDE_LAMBDA (const int elem ) {
        for( size_type pt=0; pt<basis.extent(2); pt++ ) {
          EvalT divu = dux_dx(elem,pt) + duy_dy(elem,pt);
          divu *= wts(elem,pt);
          for( size_type dof=0; dof<basis.extent(1); dof++ ) {
            res(elem,off(dof)) += divu*basis(elem,dof,pt,0);
          }
        }
      });

      if (usePSPG) {
        
        auto h = wkset->getElementSize();
        auto dpr_dx = wkset->getSolutionField("grad(pr)[x]");
        auto dpr_dy = wkset->getSolutionField("grad(pr)[y]");
        
        parallel_for("Stokes pr volume resid",
                     RangePolicy<AssemblyExec>(0,wkset->numElem),
                     MRHYDE_LAMBDA (const int elem ) {
          ScalarT alpha = 1.0;
          for (size_type pt=0; pt<basis.extent(2); pt++ ) {
            //EvalT tau = alpha*h(elem)*h(elem)/(2.*visc(elem,pt));
            EvalT tau = alpha*h(elem)/(2.*visc(elem,pt));
            EvalT Sx = dpr_dx(elem,pt) + source_ux(elem,pt);
            Sx *= tau*wts(elem,pt);
            EvalT Sy = dpr_dy(elem,pt) + source_uy(elem,pt);
            Sy *= tau*wts(elem,pt);
            for( size_type dof=0; dof<basis.extent(1); dof++ ) {
              res(elem,off(dof)) += Sx*basis_grad(elem,dof,pt,0) + Sy*basis_grad(elem,dof,pt,1);
            }
          }
        });
      }

      if (useLSIC) {
        
        auto h = wkset->getElementSize();
        auto dux_dx = wkset->getSolutionField("grad(ux)[x]");
        auto duy_dy = wkset->getSolutionField("grad(uy)[y]");
        
        parallel_for("Stokes pr volume resid",
                     RangePolicy<AssemblyExec>(0,wkset->numElem),
                     MRHYDE_LAMBDA (const int elem ) {
          ScalarT alpha = 1.0;
          for (size_type pt=0; pt<basis.extent(2); pt++ ) {
            EvalT tau = alpha*h(elem)*h(elem)/(2.*visc(elem,pt));
            EvalT stabres = dux_dx(elem,pt) + duy_dy(elem,pt);
            EvalT S = tau*stabres*wts(elem,pt);
            for( size_type dof=0; dof<basis.extent(1); dof++ ) {
              res(elem,off(dof)) += S*(basis_grad(elem,dof,pt,0) + basis_grad(elem,dof,pt,1));
            }
          }
        });
      }
    }
  }
  
  if (spaceDim == 3) {
    auto dux_dx = wkset->getSolutionField("grad(ux)[x]");
    auto dux_dy = wkset->getSolutionField("grad(ux)[y]");
    auto dux_dz = wkset->getSolutionField("grad(ux)[z]");
    auto duy_dx = wkset->getSolutionField("grad(uy)[x]");
    auto duy_dy = wkset->getSolutionField("grad(uy)[y]");
    auto duy_dz = wkset->getSolutionField("grad(uy)[z]");
    auto duz_dx = wkset->getSolutionField("grad(uz)[x]");
    auto duz_dy = wkset->getSolutionField("grad(uz)[y]");
    auto duz_dz = wkset->getSolutionField("grad(uz)[z]");
    auto Pr = wkset->getSolutionField("pr");
    
    {
      int ux_basis = wkset->usebasis[ux_num];
      auto basis = wkset->basis[ux_basis];
      auto basis_grad = wkset->basis_grad[ux_basis];
      auto off = subview(wkset->offsets,ux_num,ALL());
      parallel_for("Stokes ux volume resid",
                   RangePolicy<AssemblyExec>(0,wkset->numElem),
                   MRHYDE_LAMBDA (const int elem ) {
        for (size_type pt=0; pt<basis.extent(2); pt++ ) {
          EvalT Fx = visc(elem,pt)*dux_dx(elem,pt) - Pr(elem,pt);
          Fx *= wts(elem,pt);
          EvalT Fy = visc(elem,pt)*dux_dy(elem,pt);
          Fy *= wts(elem,pt);
          EvalT Fz = visc(elem,pt)*dux_dz(elem,pt);
          Fz *= wts(elem,pt);
          EvalT g = -source_ux(elem,pt)*wts(elem,pt);
          for (size_type dof=0; dof<basis.extent(1); dof++ ) {
            res(elem,off(dof)) += Fx*basis_grad(elem,dof,pt,0) + Fy*basis_grad(elem,dof,pt,1) + Fz*basis_grad(elem,dof,pt,2) + g*basis(elem,dof,pt,0);
          }
        }
      });
    }
    
    {
      int uy_basis = wkset->usebasis[uy_num];
      auto basis = wkset->basis[uy_basis];
      auto basis_grad = wkset->basis_grad[uy_basis];
      auto off = subview(wkset->offsets,uy_num,ALL());
      parallel_for("Stokes uy volume resid",
                   RangePolicy<AssemblyExec>(0,wkset->numElem),
                   MRHYDE_LAMBDA (const int elem ) {
        for( size_type pt=0; pt<basis.extent(2); pt++ ) {
          EvalT Fx = visc(elem,pt)*duy_dx(elem,pt);
          Fx *= wts(elem,pt);
          EvalT Fy = visc(elem,pt)*duy_dy(elem,pt) - Pr(elem,pt);
          Fy *= wts(elem,pt);
          EvalT Fz = visc(elem,pt)*duy_dz(elem,pt);
          Fz *= wts(elem,pt);
          EvalT g = -source_uy(elem,pt)*wts(elem,pt);
          for (size_type dof=0; dof<basis.extent(1); dof++ ) {
            res(elem,off(dof)) += Fx*basis_grad(elem,dof,pt,0) + Fy*basis_grad(elem,dof,pt,1) + Fz*basis_grad(elem,dof,pt,2) + g*basis(elem,dof,pt,0);
          }
        }
      });
    }
    
    {
      int uz_basis = wkset->usebasis[uz_num];
      auto basis = wkset->basis[uz_basis];
      auto basis_grad = wkset->basis_grad[uz_basis];
      auto off = subview(wkset->offsets,uz_num,ALL());
      parallel_for("Stokes uy volume resid",
                   RangePolicy<AssemblyExec>(0,wkset->numElem),
                   MRHYDE_LAMBDA (const int elem ) {
        for( size_type pt=0; pt<basis.extent(2); pt++ ) {
          EvalT Fx = visc(elem,pt)*duz_dx(elem,pt);
          Fx *= wts(elem,pt);
          EvalT Fy = visc(elem,pt)*duz_dy(elem,pt);
          Fy *= wts(elem,pt);
          EvalT Fz = visc(elem,pt)*duz_dz(elem,pt) - Pr(elem,pt);
          Fz *= wts(elem,pt);
          EvalT g = -source_uz(elem,pt)*wts(elem,pt);
          for (size_type dof=0; dof<basis.extent(1); dof++ ) {
            res(elem,off(dof)) += Fx*basis_grad(elem,dof,pt,0) + Fy*basis_grad(elem,dof,pt,1) + Fz*basis_grad(elem,dof,pt,2) + g*basis(elem,dof,pt,0);
          }
        }
      });
    }

    {
      int pr_basis = wkset->usebasis[pr_num];
      auto basis = wkset->basis[pr_basis];
      auto basis_grad = wkset->basis_grad[pr_basis];
      auto off = subview(wkset->offsets,pr_num,ALL());
      
      parallel_for("Stokes pr volume resid",
                   RangePolicy<AssemblyExec>(0,wkset->numElem),
                   MRHYDE_LAMBDA (const int elem ) {
        for( size_type pt=0; pt<basis.extent(2); pt++ ) {
          EvalT divu = dux_dx(elem,pt) + duy_dy(elem,pt) + duz_dz(elem,pt);
          divu *= wts(elem,pt);
          for( size_type dof=0; dof<basis.extent(1); dof++ ) {
            res(elem,off(dof)) += divu*basis(elem,dof,pt,0);
          }
        }
      });

      if (usePSPG) {
        
        auto h = wkset->getElementSize();
        auto dpr_dx = wkset->getSolutionField("grad(pr)[x]");
        auto dpr_dy = wkset->getSolutionField("grad(pr)[y]");
        auto dpr_dz = wkset->getSolutionField("grad(pr)[z]");
        
        parallel_for("Stokes pr volume resid",
                     RangePolicy<AssemblyExec>(0,wkset->numElem),
                     MRHYDE_LAMBDA (const int elem ) {
	  ScalarT alpha = 1.0;
	  for (size_type pt=0; pt<basis.extent(2); pt++ ) {
	    EvalT tau = alpha*h(elem)*h(elem)/(2.*visc(elem,pt));
	    EvalT Sx = dpr_dx(elem,pt) + source_ux(elem,pt);
	    Sx *= tau*wts(elem,pt);
	    EvalT Sy = dpr_dy(elem,pt) + source_uy(elem,pt);
	    Sy *= tau*wts(elem,pt);
	    EvalT Sz = dpr_dz(elem,pt) + source_uz(elem,pt);
	    Sz *= tau*wts(elem,pt);
	    for( size_type dof=0; dof<basis.extent(1); dof++ ) {
	      res(elem,off(dof)) += Sx*basis_grad(elem,dof,pt,0) + Sy*basis_grad(elem,dof,pt,1) + Sz*basis_grad(elem,dof,pt,2);
	    }
	  }
	});
      }

      if (useLSIC) {
        
        auto h = wkset->getElementSize();
        auto dux_dx = wkset->getSolutionField("grad(ux)[x]");
        auto duy_dy = wkset->getSolutionField("grad(uy)[y]");
        auto duz_dz = wkset->getSolutionField("grad(uz)[z]");
        
        parallel_for("Stokes pr volume resid",
                     RangePolicy<AssemblyExec>(0,wkset->numElem),
                     MRHYDE_LAMBDA (const int elem ) {
        ScalarT alpha = 1.0;
          for (size_type pt=0; pt<basis.extent(2); pt++ ) {
	    EvalT tau = alpha*h(elem)*h(elem)/(2.*visc(elem,pt));
	    EvalT stabres = dux_dx(elem,pt) + duy_dy(elem,pt) + duz_dz(elem,pt);
	    EvalT S = tau*stabres*wts(elem,pt);
	    for( size_type dof=0; dof<basis.extent(1); dof++ ) {
	      res(elem,off(dof)) += S*(basis_grad(elem,dof,pt,0) + basis_grad(elem,dof,pt,1) + basis_grad(elem,dof,pt,2));
	    }
	  }
	});
      }
    }
  }
}

// ========================================================================================
// ========================================================================================

template<class EvalT>
void stokes<EvalT>::boundaryResidual() {
  
}

// ========================================================================================
// The boundary/edge flux
// ========================================================================================

template<class EvalT>
void stokes<EvalT>::computeFlux() {
  
}

// ========================================================================================
// ========================================================================================

template<class EvalT>
void stokes<EvalT>::setWorkset(Teuchos::RCP<Workset<EvalT> > & wkset_) {

  wkset = wkset_;
  vector<string> varlist = wkset->varlist;

  for (size_t i=0; i<varlist.size(); i++) {
    if (varlist[i] == "ux")
      ux_num = i;
    if (varlist[i] == "pr")
      pr_num = i;
    if (varlist[i] == "uy")
      uy_num = i;
    if (varlist[i] == "uz")
      uz_num = i;
  }
  
}


//////////////////////////////////////////////////////////////
// Explicit template instantiations
//////////////////////////////////////////////////////////////

template class MrHyDE::stokes<ScalarT>;

#ifndef MrHyDE_NO_AD
// Custom AD type
template class MrHyDE::stokes<AD>;

// Standard built-in types
template class MrHyDE::stokes<AD2>;
template class MrHyDE::stokes<AD4>;
template class MrHyDE::stokes<AD8>;
template class MrHyDE::stokes<AD16>;
template class MrHyDE::stokes<AD18>;
template class MrHyDE::stokes<AD24>;
template class MrHyDE::stokes<AD32>;
#endif
